INSERT INTO INV_MST_UnitOfMeasurement([UOMName],[CreatedBy],[CreatedOn],[IsActive],[Description])
VALUES('N/A',1,GETDATE(),1,'Migrated By Imark'),
('set',1,GETDATE(),1,'Migrated By Imark');

SELECT * FROM INV_MST_UnitOfMeasurement;

