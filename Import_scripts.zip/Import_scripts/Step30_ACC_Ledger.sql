INSERT INTO ACC_Ledger([LedgerGroupId],[LedgerName],[Description],[SectionId],[LedgerReferenceId],[CreatedOn],[CreatedBy]
      ,[IsActive],[IsCostCenterApplicable],[OpeningBalance],[DrCr],[Name],[LedgerType],[Code],[PANNo],[Address]
      ,[MobileNo],[CreditPeriod],[TDSPercent],[LandlineNo],[MigrationStatus],[HospitalId],[MigrationRemark],[LegalLedgerName])
VALUES(1,'GL-Name','System Setup',NULL,NULL,GETDATE(),1,1,NULL,0,0,'ACA_INVENTORY',NULL,100,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL);


SELECT * FROM ACC_Ledger





	