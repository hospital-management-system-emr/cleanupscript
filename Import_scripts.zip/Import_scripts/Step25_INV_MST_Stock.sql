INSERT INTO INV_MST_Stock([ItemId],[BatchNo],[ExpiryDate],[CostPrice],[MRP]
      ,[Specification],[CreatedBy],[CreatedOn],[ModifiedBy],[ModifiedOn],[IsActive],[Temp_GoodsReceiptItemId])
VALUES(1,1,'2025-12-31',63715.0500,0.0000,NULL,1,GETDATE(),NULL,NULL,1,63715.0500);



