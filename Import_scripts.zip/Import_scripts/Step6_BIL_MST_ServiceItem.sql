INSERT INTO BIL_MST_ServiceItem([ServiceDepartmentId],[ItemCode],[ItemName],[IntegrationItemId],[IntegrationName],[IsTaxApplicable]
			,[Description] ,[DisplaySeq],[IsDoctorMandatory],[IsOT],[IsProc],[ServiceCategoryId],[AllowMultipleQty],[DefaultDoctorList],[IsValidForReporting],
			[IsErLabApplicable],[CreatedBy],[CreatedOn],[ModifiedBy],[ModifiedOn],[IsActive],[ItemId] ,[IsIncentiveApplicable])
VALUES(80,'ADM1','ADMISSION FEE',0,'NONE',0,NULL,100,0,0,0,1,1,NULL,0,0,1,GETDATE(),NULL,NULL,1,0,0),
      (1,'CON1','Consultation Charges',0,'OPD',0,NULL,100,0,0,0,1,1,NULL,0,0,1,GETDATE(),NULL,NULL,1,0,0)

SELECT * FROM BIL_MST_ServiceItem






