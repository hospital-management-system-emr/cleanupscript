INSERT INTO INV_FiscalYearStock([FiscalYearId],[StoreId],[StockId],[GRItemId],[ItemId]
      ,[BatchNo],[ExpiryDate],[MRP],[Price],[OpeningQty],[ClosingQty],[CreatedOn],[IsActive],[Temp_OldStockId])
VALUES(14,1,0,NULL,1,NULL,'2025-12-31',0.0000,2825.0000,25,25,GETDATE(),1,0);


