INSERT INTO ACC_MST_CodeDetails([Code],[Name],[Description],[HospitalId])
VALUES(001,'Revenue','PrimaryGroup',1);


SELECT * FROM ACC_MST_CodeDetails; 