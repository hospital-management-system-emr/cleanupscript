Insert into ACC_LedgerBalanceHistory ([FiscalYearId],[LedgerId],[OpeningBalance],[OpeningDrCr],[ClosingBalance]
      ,[ClosingDrCr],[CreatedBy],[CreatedOn],[ModifiedOn],[ModifiedBy],[HospitalId])
VALUES(1,1,0,0,0,0,1,GETDATE(),NULL,NULL,1);


SELECT * FROM ACC_LedgerBalanceHistory;