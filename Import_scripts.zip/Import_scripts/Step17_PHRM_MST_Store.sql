INSERT INTO PHRM_MST_Store([Name],[Address],[ContactNo],[Email],[StoreLabel],[StoreDescription]
      ,[CreatedOn],[CreatedBy],[ParentStoreId] ,[ModifiedBy],[ModifiedOn],[IsActive],[Code] ,[MaxVerificationLevel]
      ,[PermissionId] ,[Category],[SubCategory],[PanNo] ,[UseSeparateInvoiceHeader],[AvailablePaymentModesJSON]
      ,[DefaultPaymentMode],[INV_GRGroupId],[INV_POGroupId],[INV_PRGroupId],[INV_ReqDisGroupId],[INV_RFQGroupId]
      ,[INV_ReceiptDisplayName] ,[INV_ReceiptNoCode] ,[PrintInvoiceHeaderInDotMatrix])
VALUES('MainStore',NULL,NULL,NULL,'MainStore',NULL,GETDATE(),1,1,NULL,NULL,1,1,0,0,'store','pharmacy',NULL,
       0,NULL,NULL,NULL,	
	    NULL,NULL,NULL,NULL,NULL,NULL,0),
('MainDispensary',NULL,NULL,NULL,'MainDispensary',NULL,GETDATE(),1,1,NULL,NULL,1,1,0,955,'dispensary','dispensary',NULL,
       0,NULL,NULL,NULL,	
	    NULL,NULL,NULL,NULL,NULL,NULL,0),
('GENERAL-INVENTORY',NULL,NULL,NULL,'GENERAL-INVENTORY',NULL,GETDATE(),1,1,NULL,NULL,1,1,0,0,'store','inventory',NULL,
       0,NULL,NULL,NULL,	
	    NULL,NULL,NULL,NULL,NULL,NULL,0);

SELECT * FROM PHRM_MST_Store;

