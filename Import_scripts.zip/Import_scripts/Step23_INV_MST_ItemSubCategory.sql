INSERT INTO INV_MST_ItemSubCategory([Code],[SubCategoryName],[CreatedOn],[CreatedBy]
      ,[IsActive],[IsConsumable],[Description],[LedgerId])
VALUES('SUR','SURGICAL',GETDATE(),1,1,1,'Migrated By Imark',NULL);

SELECT * FROM INV_MST_ItemSubCategory;

