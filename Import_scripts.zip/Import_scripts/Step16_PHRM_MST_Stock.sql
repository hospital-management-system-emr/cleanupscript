INSERT INTO PHRM_MST_Stock([ItemId],[BatchNo],[ExpiryDate],[CostPrice],[SalePrice]
      ,[CreatedBy],[CreatedOn],[ModifiedBy],[ModifiedOn],[IsActive],[BarcodeId],[MRP])
VALUES(1,'a02wv005','2025-12-01 00:00:00.000',39.5000,45.0000,1,GETDATE(),NULL,NULL,1,NULL,39.5000);

SELECT * FROM PHRM_MST_Stock;
