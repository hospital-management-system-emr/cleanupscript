INSERT INTO PHRM_MST_Generic([GenericName],[GeneralCategory],[TherapeuticCategory],[Counseling],[CreatedBy]
      ,[CreatedOn],[ModifiedBy],[ModifiedOn],[IsActive],[CategoryId],[IsAllergen])
VALUES('AZITHROMYCIN 500 MG TAB',NULL,NULL,NULL,1,GETDATE(),NULL,NULL,1,1,0),
('10%DEXTROSE 500 ML IN EURO HEAD P.B',NULL,NULL,NULL,1,GETDATE(),NULL,NULL,1,1,0);

SELECT * FROM PHRM_MST_Generic;

