INSERT INTO INV_TXN_StoreStock([StoreId],[StockId],[ItemId],[SellingPrice],[AvailableQuantity]
      ,[UnConfirmedQty_In],[UnConfirmedQty_Out],[IsActive],[CostPrice],[Temp_OldStockId],[Temp_OldSubStockId],[Temp_GoodsReceiptItemId])
VALUES(1,1,1,0.0000,25,0,0,1,0.00,NULL,NULL,NULL);

SELECT * FROM INV_TXN_StoreStock;
