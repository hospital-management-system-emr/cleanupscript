INSERT INTO ACC_Bill_LedgerMapping ([LedgerId],[ServiceDepartmentId],[ItemId]
      ,[HospitalId],[SubLedgerId],[IsActive],[BillingType])
	  VALUES(1,1,1,1,1,1,'outpatient');


SELECT * FROM ACC_Bill_LedgerMapping;