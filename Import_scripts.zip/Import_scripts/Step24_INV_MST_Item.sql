INSERT INTO INV_MST_Item([ItemCategoryId],[PackagingTypeId],[ItemName],[ItemType],[Description],[ReOrderQuantity]
      ,[UnitOfMeasurementId],[MinStockQuantity],[BudgetedQuantity],[StandardRate],[VAT],[UnitQuantity],[CreatedBy]
      ,[CreatedOn],[IsActive],[Code],[CompanyId],[SubCategoryId],[ModifiedBy],[ModifiedOn],[IsVATApplicable]
      ,[MSSNO],[HSNCODE],[VendorId],[IsCssdApplicable],[IsColdStorageApplicable],[IsPatConsumptionApplicable]
      ,[MaintenanceOwnerRoleId],[StoreId],[RegisterPageNumber],[IsFixedAssets],[Remarks])
VALUES(1,1,'78 D VOLK LENS','Capital Goods','Migrated By Imark',0,2,0,0,0.0000,0.0000,0,1,GETDATE(),1	
	,'SUR250427',1,1,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL);

	SELECT * FROM INV_MST_Item;