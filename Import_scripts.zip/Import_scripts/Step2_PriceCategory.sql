
INSERT INTO BIL_CFG_PriceCategory([PriceCategoryName],[Description],[IsDefault],[CreatedOn],[CreatedBy],[IsActive]
      ,[IsPharmacyRateDifferent],[PriceCategoryCode],[ShowInRegistration],[ShowInAdmission],[DisplaySequence]
      ,[ModifiedBy],[ModifiedOn])
VALUES('General','This is a general',1,GETDATE(),1,1,NULL,'GEN1001',0,0,NULL,NULL,NULL);

SELECT *
  FROM BIL_CFG_PriceCategory


  