
INSERT INTO EMP_Employee([FirstName],[MiddleName],[LastName],[Salutation],[Gender],[ContactNumber],[DepartmentId]
      ,[DateOfBirth],[DateOfJoining],[Email],[EmployeeRoleId],[EmployeeTypeId],[ContactAddress],[Extension],[SpeedDial]
      ,[OfficeHour],[RoomNo],[Signature],[LongSignature],[MedCertificationNo],[ImageFullPath],[ImageName],[CreatedBy],[CreatedOn]
      ,[ModifiedBy],[ModifiedOn],[IsActive],[LabSignature]
      ,[IsAppointmentApplicable],[DisplaySequence],[SignatoryImageName],[FullName],[IsExternal]
      ,[PANNumber],[TDSPercent],[IsIncentiveApplicable],[RadiologySignature],[BloodGroup],[DriverLicenseNo]
      ,[NursingCertificationNo],[HealthProfessionalCertificationNo],[OpdNewPatientServiceItemId],[OpdOldPatientServiceItemId]
	  ,[FollowupServiceItemId],[InternalReferralServiceItemId])
values('Ram',NULL,'Test','Dr','male',NULL,11,'2021-06-18 00:00:00.000',GETDATE(),NULL,29,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL	
        ,NULL,NULL,NULL,1,GETDATE(),NULL,NULL,1,'Dr. Ram Test M.B.B.S, M.D Pathology Consultant Pathologist',
		0,0,'Ram_76_01092022170615.png','Dr. Ram Test',0,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

SELECT * 
  FROM EMP_Employee