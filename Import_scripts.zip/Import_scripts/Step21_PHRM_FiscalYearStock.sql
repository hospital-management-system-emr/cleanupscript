INSERT INTO PHRM_FiscalYearStock([FiscalYearId],[StoreId],[StoreType],[StockId]
      ,[ItemId],[BatchNo],[ExpiryDate],[CostPrice],[SalePrice],[OpeningQuantity],[ClosingQuantity],[Remarks]
      ,[CreatedBy],[CreatedOn],[StoreStockId])
VALUES(4,4,'store',1,1,'a02wv005','2025-12-01 00:00:00.000',39.5000,45.0000,16,3,'Migrated By Imark',1,GETDATE(),1);

SELECT * FROM PHRM_FiscalYearStock;

