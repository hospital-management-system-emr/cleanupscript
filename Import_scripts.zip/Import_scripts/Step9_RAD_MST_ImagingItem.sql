INSERT INTO RAD_MST_ImagingItem([ImagingTypeId],[ProcedureCode],[ImagingItemName],[CreatedBy]
      ,[ModifiedBy],[CreatedOn],[ModifiedOn],[IsActive],[TemplateId],[IsValidForReporting])
values(3,NULL,'XRAY (300)',1,NULL,GETDATE(),NULL,1,1,1);


INSERT INTO BIL_MST_ServiceItem([ServiceDepartmentId],[ItemCode],[ItemName],[IntegrationItemId],[IntegrationName],[IsTaxApplicable]
			,[Description] ,[DisplaySeq],[IsDoctorMandatory],[IsOT],[IsProc],[ServiceCategoryId],[AllowMultipleQty],[DefaultDoctorList],[IsValidForReporting],
			[IsErLabApplicable],[CreatedBy],[CreatedOn],[ModifiedBy],[ModifiedOn],[IsActive],[ItemId] ,[IsIncentiveApplicable])
VALUES(9,'XRAY_1','XRAY (300)',1,'Radiologys',0,NULL,100,0,0,0,1,1,NULL,0,0,1,GETDATE(),NULL,NULL,1,0,0);

SELECT * FROM RAD_MST_ImagingItem;

