INSERT INTO RAD_CFG_ReportTemplates([ModuleName],[TemplateCode]
      ,[TemplateName] ,[TemplateHTML],[FooterNote],[Remarks],[CreatedBy]
      ,[CreatedOn],[ModifiedBy],[ModifiedOn],[IsActive])
VALUES('Radiology','USG Chest','USG Chest',1,NULL,NULL,1,GETDATE(),NULL,NULL,1);

SELECT * FROM RAD_CFG_ReportTemplates;
