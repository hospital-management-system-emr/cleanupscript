INSERT INTO PHRM_TXN_StoreStock([StoreId],[StockId],[ItemId],[AvailableQuantity] ,[UnConfirmedQty_In]
      ,[UnConfirmedQty_Out],[IsActive],[CostPrice],[SalePrice])
VALUES(1,1,1,0,0,0,1,0,0);

SELECT * FROM PHRM_TXN_StoreStock;


