ALTER TABLE BIL_CFG_Counter
ALTER COLUMN CounterType VARCHAR(50) NULL
GO

INSERT INTO BIL_CFG_Counter([CounterName],[CounterType],[BeginningDate],[ClosingDate],[BranchId],[CreatedBy],[CreatedOn])
VALUES('Counter-1',NULL,NULL,NULL,NULL,1,GETDATE()),
('Counter-1','Billing',NULL,NULL,NULL,1,GETDATE());

SELECT *
  FROM BIL_CFG_Counter





