INSERT INTO PHRM_MST_Category([CategoryName],[Description],[CreatedBy],[CreatedOn],[IsActive])
VALUES('N/A','Migrate by Imark',1,GETDATE(),1);

SELECT * FROM PHRM_MST_Category;
