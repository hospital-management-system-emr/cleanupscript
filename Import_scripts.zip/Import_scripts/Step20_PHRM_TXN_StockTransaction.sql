INSERT INTO PHRM_TXN_StockTransaction([StockId],[FiscalYearId],[ItemId],[BatchNo],[ExpiryDate]
      ,[InOut],[TransactionType],[TransactionDate],[Quantity],[CostPrice],[SalePrice],[ReferenceNo]
      ,[Remarks] ,[IsActive],[IsTransferedToAcc],[CreatedBy],[CreatedOn],[StoreId],[StoreStockId]
      ,[InQty],[OutQty])
VALUES(1,4,1,'a02wv005','2025-12-01 00:00:00.000','in','opening-item','2021-06-18 23:59:59.000',16,	
      39.5000,45.0000,263,'Migrated By Imark',1,0,1,GETDATE(),1,1,16,0);

SELECT * FROM PHRM_TXN_StockTransaction;




  	