INSERT INTO PHRM_MST_ItemType([CategoryId],[ItemTypeName],[Description]
      ,[CreatedBy],[CreatedOn],[IsActive])
VALUES(1,'N/A','Migrate By Imark',1,GETDATE(),1),
(1,'IV FLUIDS','Migrate By Imark',1,GETDATE(),1);

SELECT * FROM PHRM_MST_ItemType;

