INSERT INTO ACC_MST_SubLedger (SubLedgerName,SubLedgerCode,LedgerId,Description,IsActive
		,CreatedBy,CreatedOn,OpeningBalance,DrCr,HospitalId,IsDefault)
VALUES('Hematology',111,1,NULL,1,1,GETDATE(),0,1,1,0);


SELECT * FROM ACC_MST_SubLedger;