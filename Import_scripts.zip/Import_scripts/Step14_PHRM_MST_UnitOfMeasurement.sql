INSERT INTO PHRM_MST_UnitOfMeasurement([UOMName],[Description],[CreatedBy],[CreatedOn],[IsActive])
VALUES('TAB',NULL,1,GETDATE(),1);

SELECT * FROM PHRM_MST_UnitOfMeasurement;
