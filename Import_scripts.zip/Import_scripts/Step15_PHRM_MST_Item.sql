INSERT INTO PHRM_MST_Item([ItemName],[GenericId],[ItemCode],[CompanyId],[ItemTypeId],[UOMId],[ReOrderQuantity] ,[MinStockQuantity]
      ,[BudgetedQuantity],[PurchaseVATPercentage],[IsVATApplicable],[CreatedBy],[CreatedOn],[ModifiedBy]
      ,[ModifiedOn],[IsActive],[IsInternationalBrand],[ABCCategory],[VED]
      ,[Dosage],[Frequency],[Duration],[Rack],[SalesCategoryId],[CCCharge],[IsNarcotic],[StoreRackId],[PackingTypeId]
      ,[IsInsuranceApplicable],[GovtInsurancePrice],[SalesVATPercentage],[PurchaseRate],[SalesRate] ,[PurchaseDiscount],[MRP])
VALUES('10% DEXTROSE IN EURO HEAD 500ML',2,10%1,1,2,1,0,0,0,0,0,1,GETDATE(),NULL,NULL,1,0,NULL,NULL,NULL,NULL,	
        NULL,NULL,1,0,0,NULL,1,1,70.0000,0,0,0,0,0.00)

SELECT * FROM PHRM_MST_Item;





