INSERT INTO INV_TXN_StockTransaction([StockId],[ItemId],[GoodsReceiptItemId],[Quantity],[InOut],[ReferenceNo],[CreatedBy]
      ,[CreatedOn],[TransactionType],[IsTransferredToACC],[MRP],[CostPrice],[FiscalYearId],[TransactionDate]
      ,[IsActive],[StoreId],[StoreStockId],[InQty],[OutQty],[BatchNo],[ExpiryDate],[Remarks],[Temp_OldWardStockId],[Temp_OldStockId])
VALUES(	1,1,NULL,NULL,NULL,1,1,GETDATE(),'opening-item',NULL,0.0000,3660.0700,14,GETDATE(),1,1,1,25,0,NULL,'2025-12-31','Migrated By Imark',NULL,NULL);


