INSERT INTO LAB_LabTests([LabTestCode],[LabTestName],[LabTestSpecimen],[LabTestSpecimenSource],[ReportTemplateID],[Description]
      ,[HasNegativeResults],[NegativeResultText],[ProcedureCode],[LabTestSynonym],[LOINC],[IsValidForReporting],[LabSequence],[CreatedOn]
      ,[CreatedBy],[IsActive],[ModifiedBy] ,[ModifiedOn],[DisplaySequence],[ReportingName],[Interpretation],[RunNumberType],[LabTestCategoryId]
      ,[SmsApplicable],[IsOutsourceTest],[DefaultOutsourceVendorId],[IsLISApplicable])
VALUES(NULL,'Sugar Fasting','Blood','Blood',1,NULL,0,NULL,NULL,NULL,NULL,1,100,GETDATE(),1,1,1,NULL,1,'BLOOD SUGAR',
       NULL,'normal',1,0,NULL,NULL,0);


INSERT INTO BIL_MST_ServiceItem([ServiceDepartmentId],[ItemCode],[ItemName],[IntegrationItemId],[IntegrationName],[IsTaxApplicable]
			,[Description] ,[DisplaySeq],[IsDoctorMandatory],[IsOT],[IsProc],[ServiceCategoryId],[AllowMultipleQty],[DefaultDoctorList],[IsValidForReporting],
			[IsErLabApplicable],[CreatedBy],[CreatedOn],[ModifiedBy],[ModifiedOn],[IsActive],[ItemId] ,[IsIncentiveApplicable])
VALUES(16,'Sugar_1','Sugar Fasting',1,'LAB',0,NULL,100,0,0,0,1,1,NULL,0,0,1,GETDATE(),NULL,NULL,1,0,0);









