INSERT INTO PHRM_CFG_FiscalYears([FiscalYearName],[StartDate],[EndDate],[CreatedBy],[CreatedOn]
      ,[IsActive],[NpFiscalYearName] ,[IsClosed],[ClosedOn],[ClosedBy],[FiscalYearId])
VALUES(2077/2078,'2024-01-01 23:59:59.000','2024-12-31 23:59:59.000',1,GETDATE(),1,2077/2078,	
       NULL,NULL,NULL,4);

SELECT * FROM PHRM_CFG_FiscalYears;



