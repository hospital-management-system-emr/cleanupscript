INSERT INTO BIL_CFG_Scheme([SchemeCode],[SchemeName],[Description],[CommunityName],[ValidFromDate],[ValidToDate],[IsMembershipApplicable]
      ,[IsMemberNumberCompulsory],[DefaultPaymentMode],[IsCreditApplicable],[IsCreditOnlyScheme],[IsOpCreditLimited],[IsIpCreditLimited]
      ,[IsGeneralCreditLimited],[GeneralCreditLimit],[OpCreditLimit],[IpCreditLimit],[IsRegistrationCreditApplicable]
      ,[IsOpBillCreditApplicable],[IsIpBillCreditApplicable],[IsAdmissionCreditApplicable],[IsOpPhrmCreditApplicable],[IsIpPhrmCreditApplicable]
      ,[IsVisitCompulsoryInBilling],[IsVisitCompulsoryInPharmacy],[IsBillingCoPayment],[IsPharmacyCoPayment]
      ,[BillCoPayCashPercent],[BillCoPayCreditPercent],[PharmacyCoPayCashPercent],[PharmacyCoPayCreditPercent],[IsDiscountApplicable]
      ,[DiscountPercent],[IsDiscountEditable],[IsRegDiscountApplicable],[RegDiscountPercent]
      ,[IsRegDiscountEditable],[IsOpBillDiscountApplicable],[OpBillDiscountPercent],[IsOpBillDiscountEditable],[IsIpBillDiscountApplicable]
      ,[IpBillDiscountPercent],[IsIpBillDiscountEditable],[IsAdmissionDiscountApplicable],[AdmissionDiscountPercent],[IsAdmissionDiscountEditable]
      ,[IsOpPhrmDiscountApplicable],[OpPhrmDiscountPercent],[IsOpPhrmDiscountEditable],[IsIpPhrmDiscountApplicable],[IpPhrmDiscountPercent]
      ,[IsIpPhrmDiscountEditable],[DefaultCreditOrganizationId],[CreatedBy],[CreatedOn],[ModifiedBy],[ModifiedOn],[IsActive]
      ,[ApiIntegrationName],[FieldSettingParamName],[DefaultPriceCategoryId],[IsSystemDefault],[RegStickerGroupCode],[HasSubScheme],[AllowProvisionalBilling])
VALUES('GS1001','General Scheme','This is the government for general India PM G','Hospital',
		GETDATE(),'2025-09-04',0,0,'cash',0,0,0,0,0,0.00,0.00,0.00,0,0,0,0,0,0,0,0,0,0,0.00,0.00,0.00,0.00,0,0.00
		,0,0,0.00,0,0,0.00,0,0,0.00,0,0,0.00,0,0,0.00,0,0,0.00,0,NULL,1,getdate(),NULL,NULL,1,NULL,NULL,1,1,NULL,0,0);

SELECT * FROM BIL_CFG_Scheme


 