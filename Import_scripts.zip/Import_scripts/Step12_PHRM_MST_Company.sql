INSERT INTO PHRM_MST_Company([CompanyName]
      ,[ContactNo],[Description],[ContactAddress],[Email],[CreatedBy],[CreatedOn],[IsActive],[Code])
VALUES('N/A',NULL,'Migrate by Imark',NULL,NULL,1,GETDATE(),1,'N/A');

SELECT * FROM PHRM_MST_Company;
