
Insert into BIL_CFG_FiscalYears (FiscalYearName,FiscalYearFormatted,StartYear,EndYear,Description,CreatedOn,CreatedBy,IsActive,FiscalYearId)
Values (2024,2024,'2024-01-01','2024-12-31',NULL,GETDATE(),1,1,14);


SELECT *
  FROM BIL_CFG_FiscalYears